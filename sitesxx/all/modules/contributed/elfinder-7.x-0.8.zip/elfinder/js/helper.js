// $Id: helper.js 100 2011-02-20 19:14:25Z ph0enix $

Drupal.elfinder = {
  editor: {
  
  }

}

