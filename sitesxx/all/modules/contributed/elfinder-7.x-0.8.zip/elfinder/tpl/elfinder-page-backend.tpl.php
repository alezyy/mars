<?php

/**
 * @file
 * elFinder file browser page template
 * Copyright (c) 2010, Alexey Sukhotin
 */
?>
<div id="finder"></div>
